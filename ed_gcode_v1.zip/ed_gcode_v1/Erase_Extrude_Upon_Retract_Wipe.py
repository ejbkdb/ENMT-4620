#Version 3

import re  # import regex library

reg = re.compile('E\d+\.\d+') # identifying regex for extrude format 'E123.456'

source = open("8mm_bead_thin_wall.gcode","r") # opens file called before.gcode, this is exported from slic3r
output = open("new_8mm.gcode","w") # creates output file called after.gcode
i=0

with source as f: 
    for line in f:
        if "; retract" in line:
            line = reg.sub('E0.0', line)
            output.write(line)

        else :
            output.write(line)
            
source.close()
output.close()
exit()

