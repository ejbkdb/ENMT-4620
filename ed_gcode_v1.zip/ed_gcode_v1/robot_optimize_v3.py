#Version 3

import re  # import regex library
import math #import math library
reg = re.compile('E\d+\.\d+') # identifying regex for extrude format 'E123.456'
coord = [] #Sets up an array for collecting each line
source = open("before.gcode","r") # opens file called before.gcode, this is exported from slic3r
output = open("after.gcode","w") # creates output file called after.gcode
i=0

with source as f: 
    for line in f:
        if "perimeter" in line and "width" not in line: # identifies perimeter point
            coord.append(line)
            output.write(line)
            #print (i, coord[i]) #Used to verify which i value corresponds to which coord array value
            i = i + 1
        elif "infill" in line and "width" not in line: # identifies infill point
            coord.append(line)
            output.write(line)
            i = i + 1
        elif "wipe and retract" in line: #adds wipe and retract distance
            wipe_length = 2 #Number of points in wipe
            for i in range(wipe_length):
                wipe = coord[i]
                wipe = reg.sub('E0.0', wipe)
                wipe = wipe.replace("perimeter","wipe and retract")
                wipe = wipe.replace("infill","wipe and retract")
                output.write(wipe)
                i = i + 1
        elif "; reset extrusion distance" in line: #This resets the coordinate array counter between bead paths
            i = 0
            del(coord[:])
            output.write(line)
        else :
            output.write(line)
            
source.close()
output.close()
exit()
